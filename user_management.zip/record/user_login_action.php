<?php 
	$con = new mysqli("localhost", "root", "", "user");

	if(!$con)
	{
	die("Connection failed: " . mysqli_connect_error());
	}
	
	$valid_stmt = $con->prepare("SELECT 'Success' FROM users WHERE email = ? AND password = ?");
	
	$valid_stmt->bind_param("ss", $_POST['email'], $_POST['password']);

	$valid_stmt->execute();
	
	$success = $valid_stmt->get_result();
	
	if ($success->num_rows > 0)
	{
		session_start();
		$_SESSION['email'] = $_POST['email'];
		$profile_stmt = $con->prepare("SELECT 1 FROM users WHERE email = ? and is_profile_created = ?");
		$profile_status_code = 1;
		$profile_stmt->bind_param("si", $_POST['email'], $profile_status_code);

		$profile_stmt->execute();
		
		$profile_created = $profile_stmt->get_result();
		
		if ($profile_created->num_rows > 0)
		{
			echo json_encode(array("statusCode"=>100));
		}
		else
		{
			echo json_encode(array("statusCode"=>103));
		}
	}
	else
	{
		$exist_stmt = $con->prepare("SELECT 'Success' FROM users WHERE email = ?");
	
		$exist_stmt->bind_param("s", $_POST['email']);

		$exist_stmt->execute();
		
		$success = $exist_stmt->get_result();
		
		if ($success->num_rows > 0)
		{
			echo json_encode(array("statusCode"=>101));
		}
		else
		{
			echo json_encode(array("statusCode"=>102));
		}
	}
?>