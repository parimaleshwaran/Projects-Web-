<?php
	session_start();
	$con = new mysqli("localhost", "root", "", "user");
	session_destroy();
	
	echo json_encode(array("statusCode"=>400));
?>