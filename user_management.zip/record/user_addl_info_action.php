<?php
	session_start();
	$con = new mysqli("localhost", "root", "", "user");

	if(!$con)
	{
	die("Connection failed: " . mysqli_connect_error());
	}
	
	$valid_stmt = $con->prepare("UPDATE users SET age = ?, dob = ?, mobile_number = ?, is_profile_created = ? where email = ?");
	
	$email = $_SESSION["email"];
	$profile_status_code = 1;
	$valid_stmt->bind_param("issis", $_POST['age'], $_POST['dob'], $_POST['mobile_number'], $profile_status_code, $email);

	$valid_stmt->execute();
	
	echo json_encode(array("statusCode"=>300));
?>