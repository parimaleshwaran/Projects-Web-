$(document).ready(function() {
	$('#butsave').on('click', function() {
		$("#butsave").attr("disabled", "disabled");
		var name = $('#name').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var cnfmpswd = $('#confirm').val();
		if(name!="" && email!="" && password!="" && cnfmpswd!=""){
			$.ajax({
				url: "user_registeration_action.php",
				type: "POST",
				data: {
					name: name,
					email: email,
					password: password
				},
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$("#butsave").removeAttr("disabled");
						window.location = "user_login";
						alert('Resistered Successfully');
					}
					else if(dataResult.statusCode==202){
						
						alert("Email Already Exist !");
						window.location = "user_registeration";
					   
					}
					else if(dataResult.statusCode==404){
					   alert("Error occured !");
					}
					else if(dataResult.statusCode==500){
					   alert("Internal Server Error!");
					}
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});
	
	$("#name").on("input", function(){
		var name = $("#name").val();
		if ( name=="" || name==null) {
		  $(".invalid-name:empty").append("This Field is Required");
		  $("#butsave").attr("disabled", "disabled");
		} else {
			$(".invalid-name").empty();
			$("#butsave").removeAttr("disabled");
		}
	});
	
	$("#email").on("input", function(){
		var email = $("#email").val();
		var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if (!filter.test(email)) {
		  $(".invalid-email:empty").append("Invalid Email Address");
		  $("#butsave").attr("disabled", "disabled");
		} else {
			$(".invalid-email").empty();
			$("#butsave").removeAttr("disabled");
		}
	});
	
	$("#password").on("input", function(){
		var pswd = $("#password").val();
		var filter = /^([a-zA-Z0-9!@#$%^&*()|\/?><]{8,})$/;
		if (!filter.test(pswd)) {
		  $(".invalid-password:empty").append("Password Atleast 8 Character");
		  $("#butsave").attr("disabled", "disabled");
		} else {
			$(".invalid-password").empty();
			$("#butsave").removeAttr("disabled");
		}
	});
	
	$("#confirm").on("input", function(){
		var pswd = $("#password").val();
		var cnfmpswd = $("#confirm").val();
		if ( pswd != cnfmpswd) {
		  $(".invalid-cnfmpass:empty").append("Password Mismatch");
		  $("#butsave").attr("disabled", "disabled");
		} else {
			$(".invalid-cnfmpass").empty();
			$("#butsave").removeAttr("disabled");
		}
	});
	
});