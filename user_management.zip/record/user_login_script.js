$(document).ready(function() {
	$("#butsave").on('click', function() {
		$("#butsave").attr("disabled", "disabled");
		var email = $('#email').val();
		var password = $('#password').val();
		$.ajax({
			url: "user_login_action.php",
			type: "POST",
			data: {
				email: email,
				password: password
			},
			success: function(dataResult){
				var dataResult = JSON.parse(dataResult);
				if(dataResult.statusCode==100){
					$("#butsave").removeAttr("disabled");
					window.location = "user_dashboard";
					alert('Logged In Successfully');
				}
				else if(dataResult.statusCode==101){
					alert("Wrong Password !");
					$("#butsave").removeAttr("disabled");
					$('#password').val("");
				}
				else if(dataResult.statusCode==103){
					$("#butsave").removeAttr("disabled");
					window.location = "user_addl_info";
					alert('Logged In Successfully');
				}
				else if(dataResult.statusCode==102){
					alert("Email Does Not Exist In Platform !\nPlease Register To Continue...");
					window.location = "user_registeration";
					
				}
				else if(dataResult.statusCode==404){
				   alert("Error occured !");
				}
				else if(dataResult.statusCode==500){
				   alert("Internal Server Error!");
				}
			}
		});
	});
	$("#email").on("input", function(){
	var email = $("#email").val();
	var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	if (!filter.test(email)) {
	  $(".invalid-email:empty").append("Invalid Email Address");
	} else {
		$(".invalid-email").empty();
	}
});

$("#password").on("input", function(){
	var pswd = $("#password").val();
	var filter = /^([a-zA-Z0-9!@#$%^&*()|\/?><]{8,})$/;
	if (!filter.test(pswd)) {
	  $(".invalid-password:empty").append("Password Atleast 8 Character");
	} else {
		$(".invalid-password").empty();
	}
});
});