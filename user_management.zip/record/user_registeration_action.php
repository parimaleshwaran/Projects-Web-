<?php 
	$con = new mysqli("localhost", "root", "", "user");

	if(!$con)
	{
	die("Connection failed: " . mysqli_connect_error());
	}
	
	$exist_stmt = $con->prepare("SELECT 'Success' FROM users WHERE email = ?");
	
	$exist_stmt->bind_param("s", $_POST['email']);

	$exist_stmt->execute();
	
	$success = $exist_stmt->get_result();
	
	if ($success->num_rows > 0)
	{
		echo json_encode(array("statusCode"=>202));
	}
	else
	{
		array();
		$arr_data[] = array(); // create empty array

		$myFile = "users.json";
		
		try
		{
			//Get form data
			$formdata = array(
			'user_name'=> $_POST['name'],
			'email'=> $_POST['email'],
			'password'=> $_POST['password']
			);

		  //Get data from existing json file
		   $jsondata = file_get_contents($myFile);

		   // converts json data into array
		   $arr_data = json_decode($jsondata, true);

		   // Push user data to array
		   array_push($arr_data,$formdata);

		   //Convert updated array to JSON
			$jsondata = json_encode($arr_data, JSON_PRETTY_PRINT);
			
			//Insert Data Into MySql Db Using Prepared Statement
			$stmt = $con->prepare("INSERT INTO users (display_name, email, password) VALUES (?, ?, ?)");
			
			$stmt->bind_param("sss", $_POST['name'], $_POST['email'], $_POST['password']);

			$stmt->execute();
			
			$stmt->close();
			$exist_stmt->close();
		   //write json data into data.json file
		   if(file_put_contents($myFile, $jsondata)) {
				echo json_encode(array("statusCode"=>200));
			}
		   else 
				echo json_encode(array("statusCode"=>404));
		   }

			catch (Exception $e) {
				echo json_encode(array("statusCode"=>500));
		  }
}
?>