<?php
	require_once('session_validation.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head> 
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
		<script src="user_addl_info_script.js"></script>
		<link rel="stylesheet" type="text/css" href="user_registeration_style.css">

		<title>User Registeration</title>
	</head>
	<body class="bg-danger">
		<div class="container">
			<div class="row main">
				<div class="panel-heading">
	               <div class="panel-title text-center">
	               		<h5 class="title">Enter below details to improve your profile strength.</h1>
	               	</div>
	            </div> 
				<div class="main-login main-center">
					<form class="form-horizontal" method="post" id="fupForm" name="form1" autocomplete="off">
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Age</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-edit" aria-hidden="true"></i></span>
									<input type="number" class="form-control" name="age" id="age"  placeholder="Enter your Age"/>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Date Of Birth</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-birthday-cake" aria-hidden="true"></i></span>
									<input type="date" class="form-control" name="dob" id="dob"  placeholder="Enter your Date Of Birth"/>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Mobile Number</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-mobile" aria-hidden="true"></i></span>
									<input type="mobile_number" class="form-control" name="mobile_number" id="mobile_number"  placeholder="Enter your Mobile Number"/>
								</div>
							</div>
						</div>
						<div class="form-group">
							<input type="button" name="save" class="btn btn-primary" value="Update" id="butsave">
							<input type="button" name="skip" class="btn btn-danger float-right" value="Skip" onclick="window.location= 'user_dashboard'" id="butskip">
						</div>
					</form>
				</div>
			</div>
		</div>

		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
	</body>
</html>