<html lang="en">
<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="user_login_script.js"></script>
<link rel="shortcut icon" href="favicon.ico">
</head>
<body class="bg-danger">
<div class="container">    
	<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
		<div class="panel panel-info">
				<div class="panel-heading">
					<div class="panel-title text-center">Sign In</div>
				</div>
				<div style="padding-top:30px" class="panel-body" >
					<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
					<form id="fuForm" class="form-horizontal" name="login" method="post"  autocomplete="off">
						<span class="invalid-email text-primary"></span>
						<div style="margin-bottom: 25px" class="input-group">
							<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
							<input id="email" type="email" class="form-control" name="email" value="" placeholder="Email" required>
						</div>
						<span class="invalid-password text-primary"></span>
						<div style="margin-bottom: 25px" class="input-group">
							<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
							<input id="password" type="password" class="form-control" name="password" placeholder="password" required>
						</div>
						<div style="margin-top:10px" class="form-group">
							<div class="col-sm-12 controls">
								<input type="button" name="login" class="btn btn-primary" value="Login" id="butsave">
							</div>
						</div>
						<div class="form-group" style="margin-top:10px">
							<div class="col-md-12 control">
								<div style="border-top: 1px solid#888; font-size:85%" >
									<h5 class="text-danger">Don't have an account <a href="user_registeration">Sign Up</a></h5>
								 </div>
							</div>
						</div>
					</form>
				</div>                     
		</div>  
	</div>
</div> 
</body>
</html>