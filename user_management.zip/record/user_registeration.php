
<!DOCTYPE html>
<html lang="en">
<head> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<link rel="stylesheet" type="text/css" href="user_registeration_style.css">
	<script src="user_registeration_script.js"></script>
	<title>Register</title>
</head>
<body class="bg-danger">
	<div class="container">    
	<div id="registerbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
		<div class="panel panel-info" >
				<div class="panel-heading">
					<div class="panel-title text-center">Register</div>
				</div>
				<div style="padding-top:30px" class="panel-body">
				<form id="fupForm" class="form-horizontal" method="post"autocomplete="off">
					<span class="invalid-name text-primary"></span>
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
						<input id="name" type="text" class="form-control" name="name" value="" placeholder="Enter Your Name" required>
					</div>
					<span class="invalid-email text-primary"></span>
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="fa fa-envelope fa"></i></span>
						<input id="email" type="email" class="form-control" name="email" value="" placeholder="Enter Your Email" required>
					</div>
					<span class="invalid-password text-primary"></span>
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
						<input id="password" type="password" class="form-control" name="password" placeholder="Enter Your Password" required>
					</div>
					<span class="invalid-cnfmpass text-primary"></span>
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
						<input id="confirm" type="password" class="form-control" name="confirm" placeholder="Confirm Your Password" required>
					</div>
					<div class="input-group ">
						<div>
						<input type="button" class="btn btn-primary" value = "Register" id="butsave"/>
						<input type="button" class="btn btn-danger" onclick="window.location = 'user_login'" value = "Cancel" id="butcancel">
						</div>
					</div>
					<div class="form-group" style="margin-top:10px">
							<div class="col-md-12 control">
								<div style="border-top: 1px solid#888; font-size:85%" >
									<h5 class="text-danger">Have an account <a href="user_login">Login</a></h5>
								 </div>
							</div>
					</div>    
				</form>
					</div>                     
				</div>  
	</div>
	 </div> 
</div>
</body>
</html>