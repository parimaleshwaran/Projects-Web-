$(document).ready(function() {
	$('#butsave').on('click', function() {
		$("#butsave").attr("disabled", "disabled");
			$.ajax({
				url: "user_dashboard_action.php",
				type: "POST",
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==400){
						$("#butsave").removeAttr("disabled");
						window.location = "user_login";
						alert('Logout Successfully');
					}
					else if(dataResult.statusCode==404){
					   alert("Error occured !");
					}
					else if(dataResult.statusCode==500){
					   alert("Internal Server Error!");
					}
				}
			});
	});
});