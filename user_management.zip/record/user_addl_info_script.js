$(document).ready(function() {
	$('#butsave').on('click', function() {
		$("#butsave").attr("disabled", "disabled");
		var age = $('#age').val();
		var dob = $('#dob').val();
		var mobile_number = $('#mobile_number').val();
		if(age!="" && dob!="" && mobile_number!=""){
			$.ajax({
				url: "user_addl_info_action.php",
				type: "POST",
				data: {
					age: age,
					dob: dob,
					mobile_number: mobile_number
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==300){
						$("#butsave").removeAttr("disabled");
						window.location = "user_dashboard";
						alert('Updated Successfully');
					}
					else if(dataResult.statusCode==404){
					   alert("Error occured !");
					}
					else if(dataResult.statusCode==500){
					   alert("Internal Server Error!");
					}
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});
});